package examen;

public class EXAMEN {

    public static void main(String[] args) {
       EXAMEN ex = new EXAMEN();
       int num[]={6,3,5,2,20,21};
       LeerTeclado leer = new LeerTeclado();
       int opcion = leer.leer(12, "Ingrese la opcion: ");
       switch(opcion){
           case 2: ex.operacionesMatematicas();break;
           case 3: ex.ordenacionAcsDesE(num);break;
           case 4: ex.buscarFecha();break;
       }
       
    }

    LeerTeclado leer  = new LeerTeclado();
    public void operacionesMatematicas(){
        int num1 = leer.leer(3, "Ingrese el primer numero: ");
        int num2 = leer.leer(3, "Ingrese el segundo numero: ");
        char operacion = leer.leer('A', "Ingrese la operacion: '+,-,X,/'");
        switch(operacion){
            case '+' :  System.out.println(num1 + " + " +num2+" = "+ (num1+num2));break;
            case '-' :  System.out.println(num1 + " - " +num2+" = "+ (num1-num2));break;
            case 'X' :  System.out.println(num1 + " X " +num2+" = "+ (num1*num2));
            case 'x' :  System.out.println(num1 + " X " +num2+" = "+ (num1*num2));break;
            case '/' :  System.out.println(num1 + " / " +num2+" = "+ (num1/num2));break;
            default: System.out.println("OPCION NO VALIDA");
        }
    }
    public void ordenacioAscendente(int []num){
        for (int i = 0; i < num.length; i++) {
            System.out.print("Ascendente ["+i+"]"+num[i]);
        }
    }
    public void oredenacionDescendente(int []num){
        
        for (int i = num.length-1; i >=0 ; i--) {
            System.out.print("Descente ["+i+"]"+num[i]);
        }
    }
    public void ordenacionAcsDesE(int []num){
        int temp=0;
        for (int i = 0; i < num.length; i++) {
            for (int j = 0; j < num.length-1; j++) {
                if(num[j]>num[j+1]){
                    temp= num[j];
                    num[j]= num[j+1];
                    num[j+1]=temp;
                }
            }
        }
        System.out.println("");
        System.out.println("------------");
        oredenacionDescendente(num);
        System.out.println("------------");
        ordenacioAscendente(num);
    }
    public void buscarFecha(){
        int mes = leer.leer(10, "Ingrese le mes: ");
        System.out.println("El mes "+ mes+ " esta  en la posicion "+ (mes-1));
    }
    
}
